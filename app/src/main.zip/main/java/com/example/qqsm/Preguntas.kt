package com.example.qqsm

data class Preguntas(

    var pregunta: String,
    var respuesta1: String,
    var respuesta2: String,
    var respuesta3: String,
    var respuesta4: String,
    var respuestaCorrecta : String,
    var id : Int

)